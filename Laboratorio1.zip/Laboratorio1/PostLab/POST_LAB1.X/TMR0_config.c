/* UNIVERSIDAD DEL VALLE DE GUATEMALA
 * DEPARTAMENTO DE INGENIERIA ELCTRONICA & MECATRONICA
 * CURSO: ELECTRONICA DIGITAL 2
 * LABORATORIO No.1
 * 
 * File:   TMR0_config.h
 * Author: Daniel Gonzalez 
 *
 * Created on July 20, 2023
 */
   
//-----------------------------------------------------------------------------------------------------------------------------------------------
// LIBRERIAS
//-----------------------------------------------------------------------------------------------------------------------------------------------

#include <stdint.h>
#include <pic16f887.h>
#include "TMR0_config.h"

//______________________________________________________________________________
// FUNCION DE INICIALIZACION Y CONFIGURACION DEL TMR0 �tmr0_init()� 
//______________________________________________________________________________

// Parametros: opcion prescaler y valor a cargar al TMR0

//------------------------------------------------------------------------------

void tmr0_init (uint8_t prescaler)
{
            
    INTCONbits.T0IE = 1;//tmr0 activado
    
    OPTION_REGbits.PSA = 0;  //Presc asignado al TMR0 y no al WDT
    OPTION_REGbits.T0CS = 0;  // bit 5  TMR0 Clock Source Select bit...0 = Internal Clock (CLKO) 1 = Transition on T0CKI pin
     
        
    switch(prescaler){
        case 0:
            OPTION_REGbits.PS2 = 0; // 1:2
            OPTION_REGbits.PS1 = 0;
            OPTION_REGbits.PS0 = 0;
            break;
        case 1:
            OPTION_REGbits.PS2 = 0; // 1:4
            OPTION_REGbits.PS1 = 0;
            OPTION_REGbits.PS0 = 1;
            break;
        case 2:
            OPTION_REGbits.PS2 = 0; // 1:8
            OPTION_REGbits.PS1 = 1;
            OPTION_REGbits.PS0 = 0;
            break;
        case 3:
            OPTION_REGbits.PS2 = 0; // 1:16
            OPTION_REGbits.PS1 = 1;
            OPTION_REGbits.PS0 = 1;
            break;
        case 4:
            OPTION_REGbits.PS2 = 1; // 1:32
            OPTION_REGbits.PS1 = 0;
            OPTION_REGbits.PS0 = 0;
            break;
        case 5:
            OPTION_REGbits.PS2 = 1; // 1:64
            OPTION_REGbits.PS1 = 0;
            OPTION_REGbits.PS0 = 1;
            break;
        case 6:
            OPTION_REGbits.PS2 = 1; // 1:128
            OPTION_REGbits.PS1 = 1;
            OPTION_REGbits.PS0 = 0;
            break;
        case 7:
            OPTION_REGbits.PS2 = 1; // 1:256
            OPTION_REGbits.PS1 = 1;
            OPTION_REGbits.PS0 = 1;
            break;
        default:
            OPTION_REGbits.PS2 = 1; // 1:256
            OPTION_REGbits.PS1 = 1;
            OPTION_REGbits.PS0 = 1;
            
        
    }
}

//______________________________________________________________________________
// FUNCION DE RECARGA Y LIMPIEZA DE BANDERA DEL TMR0 �tmr0_reload_v2()� 
//______________________________________________________________________________

uint8_t tmr0_reload_v2 (void)
{   
    INTCONbits.T0IF = 0;              // Limpiamos la bandera del TMR0.
    TMR0 = _tmr0_value;               // Recargamos el valor del TMRE0.
    return TMR0;
}

//______________________________________________________________________________
//______________________________________________________________________________

