/* UNIVERSIDAD DEL VALLE DE GUATEMALA
 * DEPARTAMENTO DE INGENIERIA ELCTRONICA & MECATRONICA
 * CURSO: ELECTRONICA DIGITAL 2
 * LABORATORIO No.1
 * 
 * File:   CONVER_HEXA.c
 * Author: Daniel Gonzalez 
 *
 * Created on July 20, 2023
 */

//-----------------------------------------------------------------------------------------------------------------------------------------------
// LIBRERIAS
//-----------------------------------------------------------------------------------------------------------------------------------------------

#include <stdint.h>
#include <pic16f887.h>
#include "CONVER_HEXA.h"

//______________________________________________________________________________
// FUNCION DE NUMEROS HEXADECIMALES PARA EL DISPAY DE 7SEG "int_osc_MHz()" 
//______________________________________________________________________________

// Parametros: Opcion de V1 a usar.


//------------------------ OPCIONES DE CONFIGURACION ---------------------------
/*
 El parametro "V1" es el valor del numero a mostrar en el Display:
  
  0 ----> 0
  1 ----> 1 
  2 ----> 2
  3 ----> 3
  4 ----> 4
  5 ----> 5 
  6 ----> 6
  7 ----> 7
  8 ----> 8
  9 ----> 9 
  10 ----> A
  11 ----> b
  12 ----> C
  13 ----> d 
  14 ----> E
  15 ----> F
 
 */
//------------------------------------------------------------------------------
//______________________________________________________________________________
//TABLA DE VALORES DE LOS DISPLAYS
//______________________________________________________________________________

int TABLA(int V1){
    int w;
    switch (V1){
        case 0:
        w = 0b00111111;
        break;
        case 1:
        w = 0b00000110;
        break;
        case 2:
        w = 0b01011011;
        break;
        case 3:
        w = 0b01001111;
        break;
        case 4:
        w = 0b01100110;
        break;
        case 5:
        w = 0b01101101;
        break;
        case 6:
        w = 0b01111101;
        break;
        case 7:
        w = 0b00000111;
        break;
        case 8:
        w = 0b01111111;
        break;
        case 9:
        w = 0b01101111;
        break;
        case 10:
        w = 0b01110111;
        break;
        case 11:
        w = 0b01111100;
        break;
        case 12:
        w = 0b00111001;
        break;
        case 13:
        w = 0b01011110;
        break;
        case 14:
        w = 0b01111001;
        break;
        case 15:
        w = 0b01110001;
        break;
        default:;    
    }
    return w;
}

//______________________________________________________________________________
//______________________________________________________________________________

