/*
 * File:   main_LAB1.c
 * Author: Alienware
 *
 * Created on 18 de julio de 2023, 05:00 PM
 */

//-----------------------------------------------------------------------------------------------------------------------------------------------
// CONFIG1
//-----------------------------------------------------------------------------------------------------------------------------------------------
#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is enabled)
#pragma config LVP = ON         // Low Voltage Programming Enable bit (RB3/PGM pin has PGM function, low voltage programming enabled)

//-----------------------------------------------------------------------------------------------------------------------------------------------
// CONFIG2
//-----------------------------------------------------------------------------------------------------------------------------------------------
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

//-----------------------------------------------------------------------------------------------------------------------------------------------
// LIBRERIAS
//-----------------------------------------------------------------------------------------------------------------------------------------------
#include <xc.h>
#include <stdint.h>             // AGREGAMOS LIBRERIRAS DE TIPOS DE DATOS ESTANDAR Y OTROS.
#include "ADC_LIB.h"            // AGREGAMOS LA LIBRERIRA DEL ADC.

//-----------------------------------------------------------------------------------------------------------------------------------------------
// DIRECTIVAS DEL COPILADOR
//-----------------------------------------------------------------------------------------------------------------------------------------------
#define _XTAL_FREQ 4000000      /* ESPECIFICAMOS LA FRECUENCIA DE RELOJ,
                                   PARA PODER USAR LOS DELAY EN EL PROGRAMA.*/
//______________________________________________________________________________
// PROTOTIPOS DE FUNCIONES
//______________________________________________________________________________

void SETUP(void);              // Funcion de configuraciones. 

//______________________________________________________________________________
// FUNCION DE INTERRUPCIONES
//______________________________________________________________________________

void __interrupt() isr(void){
    
//----------------------------- INTERRUPCION ADC -------------------------------     
    
  if(ADIF == 1){               // Revisamos si la bandera del ADC esta levantada.   
      if(ADCON0bits.CHS == 0){ // Revisamos si esta en el canal 0. 
         PORTD = adc_read();}  // Asignamos el valor convertido al PORTD.   
  }  
}    
    
//______________________________________________________________________________
// FUNCION PRINCIPAL (MAIN & LOOP)
//______________________________________________________________________________

void main(void){
     SETUP();                         // Llamamos a la funcion de configuracion.
     while(1){
         if(ADCON0bits.GO == 0){      // Revisamos si ya termino la conversion.
             __delay_us(50);
             ADCON0bits .GO = 1;      // Encendemos la conversion nuevamente.     
         }
     }
}

//______________________________________________________________________________
// FUNCION DE CONFIGURACION
//______________________________________________________________________________

void SETUP(void){
    
//------------------- CONFIGURACION DE ENTRADAS Y SALIDAS ----------------------
    ANSEL  = 0b00000011;    // Seleccionamos las entradas AN1 & AN2.   
    ANSELH = 0x00;          // Desactivamos las otras entradas analogicas. 
 
    TRISB = 0x00;           // Declaramos el PORTB como salidas.
    TRISC = 0x00;           // Declaramos el PORTC como salidas.
    TRISA = 0x3;            // Declaramos el pin 0 y 1 del PORTA como entradas. 
    TRISD = 0x00;           // Declaramos el PORTD com salidas.
    
    PORTB = 0x00;           // Limpiamos los puertos.
    PORTC = 0x00;
    PORTA = 0x00;
    PORTD = 0x00;  
    
//---------------------- CONFIGURACION DE RELOJ A 4MHZ -------------------------
    OSCCONbits.IRCF2 = 1;
    OSCCONbits.IRCF1 = 1;
    OSCCONbits.IRCF0 = 0;
    OSCCONbits.SCS   = 1;
    
//-------------------------- CONFIGURACION DE ADC ------------------------------
    adc_init(1,0,0);         // (Fosc/8), VDD, VSS. 
      
    adc_start(0);            // CHANEL 0, Encendemos ADC, Iniciamos conversion.

//---------------------- CONFIGURACION DE INTERRUPCIONES -----------------------
    INTCONbits.GIE  = 1;     // Habilitamos las interrupciones globales.
    INTCONbits.PEIE = 1;     // Habilitamos las interrupciones perifericas.
    PIR1bits.ADIF   = 0;     // Limpiamos la bandera del ADC.
    INTCONbits.RBIF = 0;
    INTCONbits.RBIE = 0;
}

//______________________________________________________________________________
//______________________________________________________________________________

   